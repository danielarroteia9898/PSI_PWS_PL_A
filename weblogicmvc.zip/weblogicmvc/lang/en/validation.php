<?php

$messages = [
    'name.required'     => 'Please enter Book name',
    'isbn.required'    => 'Please enter Book ISBN',
];
