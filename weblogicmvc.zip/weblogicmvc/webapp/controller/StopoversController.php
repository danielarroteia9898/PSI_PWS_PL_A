<?php


class stopoversController
{

}