<?php

use ActiveRecord\Model;

class Airport  extends Model
{


}