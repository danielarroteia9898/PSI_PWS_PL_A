<?php

use ActiveRecord\Model;

class Flight extends Model
{
    /*
    public static $has_many = array(
        array('airport'),
        array('stopover','through' => 'airport', ['foreignKey' => 'idvoo])
    );
}

$flight = Flight::first();
print_r($flight->airport);
    */
}
