<?php

use ActiveRecord\Model;

class Plane extends Model
{
    /*
    public  static $hasAndBelongsToMany = array(
        array('stopoverPlane', [['foreignKey' => 'idaviao']])
    );
    */
}