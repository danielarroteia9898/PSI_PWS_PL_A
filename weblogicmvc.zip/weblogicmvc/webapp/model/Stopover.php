<?php

use ActiveRecord\Model;

class stopover extends Model
{
/*
    public static $belongs_to = array(
        array('airport', ['foreignKey' => 'idaeroportodestino'], ['foreignKey' => 'idaeroportoorigem']),
        array('flight')
    );

    public  static $hasAndBelongsToMany = array(
        array('stopoverPlane', [['foreignKey' => 'idescala']])
    );
*/
}