<?php

use ActiveRecord\Model;
class StopoverPlane extends Model
{
    /*
    public  static $hasAndBelongsToMany = array(
        array('stopover', )
    );
    */
}